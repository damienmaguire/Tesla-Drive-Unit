
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" >
<title>Huebner Inverter Management Console</title>
    <link href="css/jquery-ui/jquery-ui.css" rel="stylesheet" type="text/css" />
	<link href="css/dataTables/dataTables.css" rel="stylesheet" type="text/css" />
    
    <script src="js/base/jquery-latest.min.js" type="text/javascript"></script>
    <script src="js/base/jquery-ui.js" type="text/javascript"></script>
    <script src="tee/src/teechart.js" type="text/javascript"></script>
    <script src="tee/src/teechart-extras.js" type="text/javascript"></script>
    <script src="tee/src/date.format.js" type="text/javascript"></script>
	<script src="js/dataTables/jquery.dataTables.js" type="text/javascript"></script>
	<script src="js/dataTables/lang/dataTables-en.js" type="text/javascript"></script>
	<script src="js/dataTables/extras/jquery.dataTables.rowGrouping.js" type="text/javascript"></script>
    <script src="js/index.js" type="text/javascript"></script>
</head>
<body>

<h3>Commands</h3>
<p><button onclick="sendCmd('get speed');">Display RPM</button></p>
<p><input type="text" id="customcmd"/> <button onclick="sendCmd($('#customcmd').val());">Send Custom Command</button></p>






<?php
require('php-serial/php_serial.class.php');
require('config.inc.php');
require('InverterTerminal.class.php');
$term = new InverterTerminal($serial);
//$combined = $term->getAttributesAndValues();  




?>    



<pre><div id="message"></div></pre>

    <div class="container">
        <div id="g1" class="gauge"></div>

    </div>
    <script src="../raphael-2.1.4.min.js"></script>
    <script src="../justgage.js"></script>
    <script>
    var g1;
    document.addEventListener("DOMContentLoaded", function(event) {
        g1 = new JustGage({
            id: "g1",
            value: 6000,
            min: 0,
            max: 18000,
            donut: true,
            gaugeWidthScale: 0.6,
            counter: true,
            hideInnerShadow: true
        });

        document.getElementById('g1_refresh').addEventListener('click', function() {
            g1.refresh(getRandomInt(0, 100));
        });
    });
    </script>



<?php
echo "</tbody></table>\n";
echo '<script type="text/javascript">';
echo 'var enumVals='.json_encode($enumVals).';';
echo "var dev = '$dev';";
echo '</script>';

?>


</body>
</html>


