<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" >
<title>Huebner Inverter Management Console</title>
    <link href="css/jquery-ui/jquery-ui.css" rel="stylesheet" type="text/css" />
	<link href="css/dataTables/dataTables.css" rel="stylesheet" type="text/css" />
    
    <script src="js/base/jquery-latest.min.js" type="text/javascript"></script>
    <script src="js/base/jquery-ui.js" type="text/javascript"></script>
    <script src="tee/src/teechart.js" type="text/javascript"></script>
    <script src="tee/src/teechart-extras.js" type="text/javascript"></script>
    <script src="tee/src/date.format.js" type="text/javascript"></script>
	<script src="js/dataTables/jquery.dataTables.js" type="text/javascript"></script>
	<script src="js/dataTables/lang/dataTables-en.js" type="text/javascript"></script>
	<script src="js/dataTables/extras/jquery.dataTables.rowGrouping.js" type="text/javascript"></script>
    <script src="js/index.js" type="text/javascript"></script>
</head>
<body>

<h3>Commands</h3>
<p><button onclick="sendCmd('save');">Save Parameters to Flash</button></p>
<p><button onclick="sendCmd('load');">Restore Parameters from Flash</button></p>
<p><button onclick="sendCmd('defaults');">Restore Defaults</button></p>
<p><button onclick="sendCmd('start 2');">Start Inverter in manual Mode</button></p>
<p><button onclick="sendCmd('stop');">Stop Inverter</button></p>
<p><button onclick="sendCmd('errors');">Display Error Memory</button></p>
<p><button onclick="sendCmd('can clear');">Reset CAN Mapping</button></p>
<p><input type="text" id="customcmd"/> <button onclick="sendCmd($('#customcmd').val());">Send Custom Command</button></p>

<h3>Parameters</h3>
<p><a href="http://johanneshuebner.com/quickcms/index.html%3Fen_parameters,24.html" target="_blank">Parameter Reference</a>
<p>Modified Values are in bold</p>
<form action="download.php"><input type="submit" value="Download Parameters to file"> (stop plot before doing this!)</form>
<p>
<form enctype="multipart/form-data" action="" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="3000" />
    <input name="userfile" type="file" />
    <input type="submit" value="Load Parameters from file" />
</form>

<?php

require('php-serial/php_serial.class.php');
require('config.inc.php');
require('InverterTerminal.class.php');

$term = new InverterTerminal($serial);

$combined = $term->getAttributesAndValues();

if (count($_FILES))
{
    $string = file_get_contents($_FILES['userfile']['tmp_name']);
    $params = (array)json_decode($string);
?>    
<div id="upload"><p>
    <button onclick="document.getElementById('upload').style.display = 'none';">Hide Messages</button>
    <pre>
<?php
    
    $term->sendCmd("stop");
    echo "\n";
    
    foreach ($combined as $name => $attributes)
    {
        if ($attributes->isparam)
        {
            $term->sendCmd("set ".$name." ".$params[$name], false, 0.01);
            echo "\n";
        }
    }
?>
    </pre>
</div>
<?php
    $term->getValues($combined);
}
?>
<p>Type new value and hit enter to change. Only change one value at a time.</p>
<p>Message: 
<pre><div id="message"></div></pre>
<p><button onclick="updateTables();">Update Tables</button></p>

<table id="params" class="dataTable">
<thead>
<tr>
	<th>Category</th>
	<th>Name</th>
	<th>Value</th>
	<th>Unit</th>
	<th>Minimum</th>
	<th>Maximum</th>
	<th>Default</th>
</tr>
</thead>
<tbody>
<?php

foreach ($combined as $name => $attributes)
{
    if ($attributes->isparam)
    {
        $value = $attributes->value;
        $unit = $attributes->unit;
        $min = $attributes->minimum;
        $max = $attributes->maximum;
        $def = $attributes->default;
        $enum = $attributes->enum;
        $category = isset($attributes->category) ? $attributes->category : "";

        if ($enum)
        {
            $valedit = "<select id=\"val$name\" name=\"$name\" onchange=\"sendCmd('set $name '+this.value);\">\n";
            foreach ($enum as $evalue => $ename)
            {
                $selected = "";
                if ($value == $evalue)
                    $selected = "selected=\"yes\"";
                $valedit .= "<option $selected value=\"$evalue\">$ename</option>\n";
            }
            $valedit .= "</select>\n";
        }
        else
        {
            $style = "";
            if ($value != $def)
               $style = 'style="font-weight:bold"';
            $valedit = "<input id=\"val$name\" name=\"$name\" $style type=\"text\" value=\"$value\">";
        }
        
        echo "
	<tr>
		<td>$category</td>
		<td>$name</td>
		<td>$valedit</td>
		<td>$unit</td>
		<td>$min</td>
		<td>$max</td>
		<td>$def</td>
	</tr>";
    }
}
?>

</tbody></table>

<h3>Spot Values</h3>
<p><button onclick="updateTables();">Update Tables</button></p>
<table border=1 id="spotValues"><thead>
<tr><th>Name</th><th>Value</th><th>Unit</th><th>Plot</th><th>CAN Id</th><th>Position</th><th>Bits</th><th>Gain</th></tr>
</thead>
<tbody>

<?php
$enumVals = array();

foreach ($combined as $name => $attributes)
{
    if (!$attributes->isparam)
    {
        $value = $attributes->value;
        $unit = $attributes->unit;
        $enum = $attributes->enum;
        if ($enum)
        {
            $value = $enum[$value];
            $enumVals[$name] = $enum;
        }
        
        echo "<tr><td>$name</td><td id=\"val$name\">$value</td><td>$unit</td><td>
        <input type=checkbox data-name=\"$name\" data-axis=\"left\">l 
        <input type=checkbox data-name=\"$name\" data-axis=\"right\">r </td>
        <td><input size=4 type=text id=\"canid$name\"/></td>
        <td><input size=4 type=text id=\"canpos$name\"/></td>
        <td><input size=4 type=text id=\"canbits$name\"/></td>
        <td><input size=4 type=text id=\"cangain$name\"/> <button id=\"$name\" onclick=\"canmap(this.id)\">Map to CAN</button></td>
        </tr>";
    }
}

echo "</tbody></table>\n";
echo '<script type="text/javascript">';
echo 'var enumVals='.json_encode($enumVals).';';
echo "var dev = '$dev';";
echo '</script>';

?>
<h2>Plot</h2>
<canvas id="canvas" width=1000 height=500></canvas>
<p>
<button onclick="start()">Start Plot</button>
<button onclick="stop()">Stop Plot</button>
<button onclick="pauseResume()" disabled id="pauseButton">Pause Plot</button>
<button onclick="save()">Save Plot to Image</button>

</body>
</html>
