<?php
ini_set("display_errors", "1");
error_reporting(E_ALL);

require('php-serial/php_serial.class.php');
require('config.inc.php');
require('InverterTerminal.class.php');

$term = new InverterTerminal($serial);

$term->sendCmd($_GET['cmd']);
    $serial->deviceOpen();


sendCmd(get speed);


    // Read data
    $read = $serial->readPort();

    // Print out the data
    $data = preg_split('/\s+/', $read);
    //print_r($data); // red and split the data by spaces to array
    $array = array_count_values($data); // count the array values
    $values = array_keys($array, max($array)); // count the maximum repeating value
    echo $values[0];
    // If you want to change the configuration, the device must be closed.
    $serial->deviceClose();
?>
