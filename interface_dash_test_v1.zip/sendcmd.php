<?php

require('php-serial/php_serial.class.php');
require('config.inc.php');
require('InverterTerminal.class.php');

$term = new InverterTerminal($serial);

$term->sendCmd($_GET['cmd']);
?>