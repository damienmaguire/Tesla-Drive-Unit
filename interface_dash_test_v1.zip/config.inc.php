<?php

$serial = new phpSerial;

$dev = "/dev/ttyUSB0";
if (isset($_GET['d']))
	$dev = $_GET['d'];

if (!$serial->deviceSet($dev))
{
	die();
}

$serial->confBaudRate(115200);
$serial->confParity("none");
$serial->confCharacterLength(8);
$serial->confStopBits(2);
$serial->confFlowControl("none");
$serial->echoOff();
$serial->deviceOpen();

?>
