<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>Pointer</title>
    <meta name="viewport" content="width=device-width">
    <link href="css/jquery-ui/jquery-ui.css" rel="stylesheet" type="text/css" />
    <link href="css/dataTables/dataTables.css" rel="stylesheet" type="text/css" />
    
    <script src="js/base/jquery-latest.min.js" type="text/javascript"></script>
    <script src="js/base/jquery-ui.js" type="text/javascript"></script>
    <script src="tee/src/teechart.js" type="text/javascript"></script>
    <script src="tee/src/teechart-extras.js" type="text/javascript"></script>
    <script src="tee/src/date.format.js" type="text/javascript"></script>
    <script src="js/dataTables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="js/dataTables/lang/dataTables-en.js" type="text/javascript"></script>
    <script src="js/dataTables/extras/jquery.dataTables.rowGrouping.js" type="text/javascript"></script>
    <script src="js/index.js" type="text/javascript"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/dashboard_css.css" />
   
  </head>
  <script type="text/javascript">
    var fetchedSpeed=0;
    var fetchedUdc=0;
    var fetchedIl1rms=0;
    var fetchedIl2rms=0;
    var fetchedDir=0;
    var fetchedTmphs=0;
    var fetchedTmpm=0;
    var fetchedPotnom=0;

    var keyCommands=[
        "get speed",
        "get udc",
        "get il1rms",
        "get il2rms",
        "get dir",
        "get tmphs",
        "get tmpm",
        "get potnom"
    ];

    var getCommands=[];
    function sendCmdArr(keycmd){
	//alert(fetchedUdc);
        var xmlhttp=new XMLHttpRequest();
        var req = "sendCmdArr.php?cmd="+keycmd;
        var delay = 0;

        xmlhttp.onload = function(){
            if (this.plotResume) pauseResume();
            getCommands.push(this.responseText);
        }

        xmlhttp.open("GET", req, true);
        pausePlotAndSend(xmlhttp);
    }

    function checkGetResponses(){
        speed.refresh(getCommands[0]);
        fetchedSpeed = getCommands[0];

        udc.refresh(getCommands[1]);
        fetchedUdc = getCommands[1];

        il1rms.refresh(getCommands[2]);
        fetchedIl1rms = getCommands[2];

        il2rms.refresh(getCommands[3]);
        fetchedIl2rms = getCommands[3];

        dir.refresh(getCommands[4]);
        fetchedDir = getCommands[4];

        tmphs.refresh(getCommands[5]);
        fetchedTmphs = getCommands[5];

        tmpm.refresh(getCommands[6]);
        fetchedTmpm = getCommands[6];

        potnom.refresh(getCommands[7]);
        fetchedPotnom = getCommands[7];
	
//alert(fetchedUdc);	

       	//alert('speed'+fetchedSpeed+' udc'+fetchedUdc+' il1rms'+fetchedIl1rms+' il2rms'+fetchedIl2rms+' dir'+fetchedDir+' tmphs'+fetchedTmphs+' tmpm'+fetchedTmpm+' potnom'+fetchedPotnom);
    }

    var i = 0; 
    function startInverter(){  
        setTimeout(function () { 
            //alert(keyCommands[i]); 
            if(i <= 7){ 
                sendCmdArr(keyCommands[i]);    
                //getCommands.push(keyCommands[i]);
                i++;
                startInverter(); 
            }else{
                checkGetResponses();
                return;
            }  

        }, 500);
    }

    function resetValues(){
    	speed.refresh(0);
        fetchedSpeed = 0;

        udc.refresh(0);
        fetchedUdc = 0;

        il1rms.refresh(0);
        fetchedIl1rms = 0;

        il2rms.refresh(0);
        fetchedIl2rms = 0;

        dir.refresh(0);
        fetchedDir = 0;

        tmphs.refresh(0);
        fetchedTmphs = 0;

        tmpm.refresh(0);
        fetchedTmpm = 0;

        potnom.refresh(0);
        fetchedPotnom = 0;
    }

    function startContinuesly(){
	startInverter();
    	setTimeout(function () {startContinuesly();}, 5000);
    }
    startContinuesly();
    //startInverter();
  </script>
  <body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Inverter Estimation</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#about">Eport CSV</a></li>
            <li><a href="#contact" onclick=startContinuesly();>Refresh</a></li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="speed" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">SPEED</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="udc" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">UDC</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="il1rms" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">IL1RMS</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="il2rms" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">IL2RMS</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="dir" class="gauge">
                                <div class="lbl_1">Neutral</div>
                                <div class="lbl_2">Start</div>
                                <div class="lbl_3">Other</div>
                            </div>
                          <div class="caption">
                            <h3 class="guage_text">DIR</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="tmphs" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">TMPHS</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="tmpm" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">TMPM</h3>
                          </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <div id="potnom" class="gauge"></div>
                          <div class="caption">
                            <h3 class="guage_text">POTNOM</h3>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
        require('php-serial/php_serial.class.php');
        require('config.inc.php');
        require('InverterTerminal.class.php');
        $term = new InverterTerminal($serial);
        //$combined = $term->getAttributesAndValues();  
    ?> 
    
    <div class="container">
      <button type="button" id="gauge_refresh">Refresh Gauges</button>
    </div>
    <script src="js/raphael-2.1.4.min.js"></script>
    <script src="js/justgage.js"></script>

    <script>
	var speed = new JustGage({
        id: 'speed',
        value: fetchedSpeed,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#f44336',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var udc = new JustGage({
        id: 'udc',
        value: fetchedUdc,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#e91e63',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var il1rms = new JustGage({
        id: 'il1rms',
        value: fetchedIl1rms,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#673ab7',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var il2rms = new JustGage({
        id: 'il2rms',
        value: fetchedIl2rms,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#03a9f4',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var dir = new JustGage({
        id: 'dir',
        value: fetchedDir,
        min: 0,
        max: 2,
        symbol: '',
        pointer: true,
        pointerOptions: {
          toplength: -15,
          bottomlength: 10,
          bottomwidth: 12,
          color: '#8e8e93',
          stroke: '#ffffff',
          stroke_width: 3,
          stroke_linecap: 'round'
        },
        gaugeWidthScale: 0.6,
        counter: true
      });
      
      var tmphs = new JustGage({
        id: 'tmphs',
        value: fetchedTmphs,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#ff5722',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var tmpm = new JustGage({
        id: 'tmpm',
        value: fetchedTmpm,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#9c27b0',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });
      var potnom = new JustGage({
        id: 'potnom',
        value: fetchedPotnom,
        min: 0,
        max: 100,
        symbol: '',
        pointer: true,
        gaugeWidthScale: 0.6,
        customSectors: [{
          color: '#ff9800',
          lo: 50,
          hi: 100
        }, {
          color: '#00ff00',
          lo: 0,
          hi: 50
        }],
        counter: true
      });

      
	$(document).ready(function(){
		$('#dir tspan').each(function(){
		    $(this).html('');
		    $(this).css('display', 'none');
		});
        });
    </script>
  </body>

</html>

