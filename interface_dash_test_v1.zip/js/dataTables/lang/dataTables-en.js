var dataTablesLanguage = {
	'oPaginate': {
		'sFirst': 'First',
		'sLast': 'Last',
		'sNext': 'Next',
		'sPrevious': 'Previous'
	},
	'sZeroRecords': 'No matching records found.',
	'sEmptyTable': 'No data available.',
	'sInfoEmpty': '<span class="noResults">Showing 0 to 0 of 0 entries</span>',
	'sInfo': 'Showing _START_ to _END_ of _TOTAL_ entries',
	"sInfoFiltered": " (filtered from _MAX_ total entries)",
	'sInfoThousands': ',',
	'sLengthMenu': 'Show _MENU_ entries',
	'sLoadingRecords': 'Please wait - loading …',
	'sProcessing': 'DataTables is currently busy …',
	'sSearch': '',
	'plugins': {
		'ColVis': {
			'buttonText': 'Column'
		}
	}
};